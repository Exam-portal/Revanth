package com.model;

import javax.validation.constraints.NotNull;

public class UserPassword {
	@NotNull
	private int id;
	
	@NotNull
	private String password;
	

}
