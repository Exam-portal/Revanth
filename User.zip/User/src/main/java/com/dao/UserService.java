package com.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.User;


	@Service
	public class UserService {

		@Autowired
		UserDAOImpl userDaoImpl;
		
//		public List<User> getAllResult(int userId) {
//			return resultDaoImpl.findAllResult(userId);
//		}

		public String login(User result) {
			return userDaoImpl.login(result);
		}

		public void add(User user) {
			userDaoImpl.add(user);
		}

		public void changePassword(User user) {
			userDaoImpl.changePassword(user);
		}
		
		
	}


