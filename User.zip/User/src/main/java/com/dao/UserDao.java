package com.dao;


	import org.springframework.stereotype.Repository;

import com.model.User;

	@Repository
	public interface UserDao {

		public String login(User user);
		public void add(User user);
		public void changePassword(User user);
//		public Result findResult(int id);
//		public List<User> findAllResult(int userId);
//		public boolean updateResult(Result Result);
//		public boolean deleteResult(Result Result);
	}


