package com.dao;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.model.User;

@Component
public class UserDAOImpl implements UserDao {
	@Autowired
	SessionFactory sessionFactory;


	@Override
	public String login(User user) {
		Session session=sessionFactory.openSession();
		Query query = session.createQuery("select u from User u where u.id = :userId and u.password = :password");
		User userDetails=session.find(User.class, user.getId());
		if(userDetails.getPassword().equals(user.getPassword())) {
			return "Success";
		}
		return "Fail";
		// TODO Auto-generated method stub
		
	}

	@Override
	public void add(User user) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(user);
		session.flush();
		session.getTransaction().commit();
		session.close();		
	}
		// TODO Auto-generated method stub
		
	

	@Override
	public void changePassword(User user) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		User userDetails=session.find(User.class, user.getId());
		userDetails.setPassword(user.getPassword());
		session.update(userDetails);
		session.flush();
		session.getTransaction().commit();
		session.close();
		// TODO Auto-generated method stub
		
	}

}
