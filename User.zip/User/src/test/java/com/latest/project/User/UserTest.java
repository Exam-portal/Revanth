package com.latest.project.User;
import static org.junit.jupiter.api.Assertions.assertEquals;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dao.UserService;
import com.model.User;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
@SpringBootTest
class UserTest {
	@Autowired
	UserService userService;
	

	@Test
	void testLogin() {
		User user = new User();
		user.setId(1);
		user.setPassword("12345");
		assertEquals("Success", userService.login(user));
	}
	

	@Test
	void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	void testChangePassword() {
		User user = new User();
		user.setId(1);
		user.setPassword("1234");
		userService.changePassword(user);
		assertEquals("Success", userService.login(user));
		user.setPassword("12345");
		userService.changePassword(user);
	}
	@Test
	void testLoginFailure() {
		User user = new User();
		user.setId(1);
		user.setPassword("1234");
		assertEquals("Fail", userService.login(user));
	}
	//@Test
	//void testViewPassword() {
	//	User user = new User();
	//	user.setId(1);
	//	assertEquals("12345", userService.viewPassword(user));
	//}


}
