package com.revanth.onlineexam.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.revanth.onlineexam.model.User;

@Component
public class UserDaoImpl implements UserDao{

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public String login(User user) {
		Session session=sessionFactory.openSession();
		User userDetails=session.find(User.class, user.getId());
		if(userDetails.getPassword().equals(user.getPassword())) {
			return "Success";
		}
		return "Fail";
	}

	@Override
	public void add(User user) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(user);
		session.flush();
		session.getTransaction().commit();
		session.close();		
	}

	@Override
	public void changePassword(User user) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		User userDetails=session.find(User.class, user.getId());
		userDetails.setPassword(user.getPassword());
		session.update(userDetails);
		session.flush();
		session.getTransaction().commit();
		session.close();
	}

	@Override
	public String viewPassword(User user) {
		Session session=sessionFactory.openSession();
		User userDetails=session.find(User.class, user.getId());
		session.close();
		if(userDetails!=null) {
			return userDetails.getPassword();
		}
		return "No User Found";
	}
	
	
}
