package com.revanth.onlineexam.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.revanth.onlineexam.dao.UserService;
import com.revanth.onlineexam.model.User;

@RestController
public class UserController {

	@Autowired
	UserService userService;
	
//	@GetMapping("/getResults/{userId}")
//	public List<User> getAllResults(@PathVariable(value="userId") int userId) {
//		return resultService.getAllResult(userId);
//	}
//	
	@GetMapping("/login")
	public String login(@RequestBody User user) {
		return userService.login(user);
	}
	
	@PostMapping("/registration")
	public String addUser(@RequestBody User user) {
		userService.add(user);
		return "user added successfully";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(@RequestBody User user) {
		userService.changePassword(user);
		return "password changed successfully";
	}
	
	@GetMapping("/viewPassword")
	public String viewPassword(@RequestBody User user) {
		return userService.viewPassword(user);
	}
}
