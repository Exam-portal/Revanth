package com.revanth.onlineexam.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.revanth.onlineexam.model.User;

@Service
public class UserService {

	@Autowired
	UserDaoImpl userDaoImpl;

	public String login(User user) {
		return userDaoImpl.login(user);
	}

	public void add(User user) {
		userDaoImpl.add(user);
	}

	public void changePassword(User user) {
		userDaoImpl.changePassword(user);
	}

	public String viewPassword(User user) {
		return userDaoImpl.viewPassword(user);
	}
}
