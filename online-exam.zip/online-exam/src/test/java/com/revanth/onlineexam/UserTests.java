package com.revanth.onlineexam;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.revanth.onlineexam.dao.UserService;
import com.revanth.onlineexam.model.User;

@SpringBootTest
public class UserTests {

	@Autowired
	UserService userService;
	

	@Test
	void testLoginSuccess() {
		User user = new User();
		user.setId(1);
		user.setPassword("12345");
		assertEquals("Success", userService.login(user));
	}
	
	@Test
	void testLoginFailure() {
		User user = new User();
		user.setId(1);
		user.setPassword("1234");
		assertEquals("Fail", userService.login(user));
	}
	
	@Test
	void testChangePassword() {
		User user = new User();
		user.setId(1);
		user.setPassword("1234");
		userService.changePassword(user);
		assertEquals("Success", userService.login(user));
		user.setPassword("12345");
		userService.changePassword(user);
	}
	
	@Test
	void testViewPassword() {
		User user = new User();
		user.setId(1);
		assertEquals("12345", userService.viewPassword(user));
	}

}
