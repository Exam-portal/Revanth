package com.online.project;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.dao.UserRRDAO;
import com.dao.UserRRService;
import com.model.UserRR;
@SpringBootTest

class UserTest {
	@Autowired
	UserRRService service;
	

	@Test
	void testAdd() {
		UserRR_Management test = new UserRR_Management();
		test.setLogin("Name");
		test.setTestId(50);
		test.Address("abc");
		test.Mail("abc@123");
		Service.add(test);
		
		UserRR_Management test_to_be_added=Service.findTest(test.getTest_Id());
		Assert.assertEquals("Name", test_to_be_added.getLogin());
		Assert.assertEquals(50, test_to_be_added.getTest_Id());
		Assert.assertEquals("abc", test_to_be_added.getAddress());
		Assert.assertEquals("abc@123",test_to_be_added.Mail());
		

			}


	@Test
	void testFind() {
		UserRR_Management test = new UserRR_Management();
		test.setLogin("Name");
		test.setTest_Id(50);
		test.Address("abc");
		test.Mail("abc@123");
		Service.findTest(test);
		UserRR_Management test_to_be_find=Service.findTest(test.getTest_Id());
		Assert.assertEquals("Name", test_to_be_find.getLogin());
		Assert.assertEquals(50, test_to_be_find.getTest_Id());
		Assert.assertEquals("abc", test_to_be_find.getAddress());
		Assert.assertEquals("abc@123",test_to_be_find.getMail());
		
		
	}

	@Test
	void testFinalAll() {
		UserRR_Management test = new UserRR_Management();
		test.setLogin("Name");
		test.setTest_Id(50);
		test.Address("abc");
		test.ViewPassword("abc@123");
		Service.finalAll(test);
		UserRR_Management test_to_be_finalAll=Service.findTest(test.getTest_Id());
		Assert.assertEquals("Name", test_to_be_finalAll.getLogin());
		Assert.assertEquals(50, test_to_be_finalAll.getTest_Id());
		Assert.assertEquals("abc", test_to_be_finalAll.getAddress());
		Assert.assertEquals("abc@123",test_to_be_finalAll.getMail());
		
	}

	@Test
	void testUpdate() {
		UserRR_Management test = new UserRR_Management();
		test.setLogin("Name");
		test.setTest_Id(50);
		test.Address("abc");
		test.Mail("abc@123");
		Service.add(test);
		UserRR_Management test_to_be_updated=Service.findTest(test.getTest_Id());
		Assert.assertEquals("Name", test_to_be_updated.getLogin());
		Assert.assertEquals(50, test_to_be_updated.getTest_Id());
		Assert.assertEquals("abc", test_to_be_updated.getAddress());
		Assert.assertEquals("abc@123",test_to_be_updated.getMail());
		
	}

	@Test
	void testDelete() {
		UserRR_Management test = new UserRR_Management();
		test.setLogin("Name");
		test.setTest_Id(50);
		test.Address("abc");
		test.Mail("abc@123");
		Service.add(test);
		
		UserRR_Management test_to_be_delete=Service.findTest(test.getTest_Id());
		Assert.assertEquals("Name", test_to_be_delete.getLogin());
		Assert.assertEquals(50, test_to_be_delete.getTest_Id());
		Assert.assertEquals("abc", test_to_be_delete.getAddress());
		Assert.assertEquals("abc@123",test_to_be_delete.getMail());
		
	
	}

}
