package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.UserRR;

@Service


public class UserRRService {
	
	@Autowired
	UserRRDAO UserRRDAOImpl;
	public void add(UserRR userRR) {
		UserRRDAOImpl.addUserRR(userRR);
		
	}
	public UserRR find(int id) {
		return UserRRDAOImpl.findUserRR(id);
	}
	public List<UserRR>finalAll(){
		return UserRRDAOImpl.findAllUserRR();
	}
	public boolean update(UserRR userRR) {
		return UserRRDAOImpl.updateUserRR(userRR);
		
	}
	public boolean delete(UserRR userRR) {
		return UserRRDAOImpl.deleteUserRR(userRR);
	}
}


