package com.dao;

import java.util.List;

import com.model.UserRR;

public class UserRRDAO {
	
	public  void addUserRR(UserRR userRR) {
	}
	public UserRR findUserRR(int id) {
		return null;
	} 
	public List<UserRR>findAllUserRR() {
		return null;
	}
	public boolean updateUserRR(UserRR userRR) {
		return false;
	}
	public boolean deleteUserRR(UserRR userRR) {
		return false;
	}
		
	}
	


