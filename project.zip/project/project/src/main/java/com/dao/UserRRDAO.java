package com.dao;

import java.util.List;

public class UserRRDAO {
	
	public void addUserRR(UserRR userRR);
	public UserRR findUserRR(int id); 
	public List<UserRR>findAllUserRR();
	public boolean updateUserRR(UserRR userRR);
	public boolean deleteUserRR(UserRR userRR);
		
	}
	


