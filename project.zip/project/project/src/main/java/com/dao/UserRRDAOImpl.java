package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class UserRRDAOImpl implements UserRRDAO{
	private static final Object UserRR = null;
	@Autowired
	SessionFactory sessionFactory;
	public void addUserRR(UserRR userRR) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(userRR);
		session.getTransaction().commit();
		session.close();
	}
	
	
	public UserRR findUserRR(int id) {
		Session session=sessionFactory.openSession();
		UserRR userRR=session.find(UserRR.class, id);
		return userRR;
	}
     public List<UserRR> findAllUserRR(){
    	 Session session=sessionFactory.openSession();
    	 List<UserRR>userRRlist=session.createQuery("select t from UserRR t").list();
    	 return userRRlist;
     }
     
     public boolean updateUserRR(UserRR userRR) {
    	 Session session=sessionFactory.openSession();
    	 session.getTransaction().begin();
    	 session.update(UserRR);
    	 session.flush();
    	 session.getTransaction().commit();
    	 session.close();
    	 return true;
     }
     public boolean deleteUserRR(UserRR userRR) {
     Session session=sessionFactory.openSession();
	 session.getTransaction().begin();
	 session.update(userRR);
	 session.flush();
	 session.getTransaction().commit();
	 session.close();
	 return true;
 }
     }

