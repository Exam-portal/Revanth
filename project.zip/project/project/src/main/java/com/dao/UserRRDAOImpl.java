package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class UserRRDAOImpl implements UserRRDAO{
	private static final Object UserRR = null;
	@Autowired
	SessionFactory sessionFactory;
	public void addUserRR(UserRRDAO userRR) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(userRR);
		session.getTransaction().commit();
		session.close();
	}
	
	
	public UserRRDAO findUserRR(int id) {
		Session session=sessionFactory.openSession();
		UserRRDAO userRR=session.find(UserRR.class, id);
		return userRR;
	}
     public List<UserRR> findAllUserRR(){
    	 Session session=sessionFactory.openSession();
    	 List<UserRR>userRRlist=session.createQuery("select t from UserRR t").list();
    	 return userRRlist;
     }
     
     public boolean updateUserRR(UserRRDAO userRR) {
    	 Session session=sessionFactory.openSession();
    	 session.getTransaction().begin();
    	 session.update(UserRR);
    	 session.flush();
    	 session.getTransaction().commit();
    	 session.close();
    	 return true;
     }
     public boolean deleteUserRR(UserRRDAO userRR) {
     Session session=sessionFactory.openSession();
	 session.getTransaction().begin();
	 session.update(userRR);
	 session.flush();
	 session.getTransaction().commit();
	 session.close();
	 return true;
 }
     }

