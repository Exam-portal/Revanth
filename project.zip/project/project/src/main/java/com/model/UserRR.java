package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

@Entity
public class UserRR {
	
	@Id
	@GeneratedValue
	
	
	public void Name() {}
	public void Id() {}
	public void Address() {}
	public void Mail() {}
	
	
		public int getUserRR_Id() {
			return getUserRR_Id();
		}
		public void setUserRR_Id(int UserRR_Id) {
			UserRR_Id = getUserRR_Id();
		}
		public String getUserRR_Name() {
			return "UserRR_Name";
		}
		public void setUserRR_Id(String UserRR_Name) {
			UserRR_Name = getUserRR_Name();
		}
		public String getUserRR_Address() {
			return "UserRR_Address";
		}
		public void setUserRR_Address(String UserRR_Address) {
			UserRR_Address = getUserRR_Address();
			
		}
		public String getUserRR_Mail() {
			return "UserRR_Mail";
		}
		public void setUserRR_Mail(String UserRR_Mail) {
			UserRR_Mail = getUserRR_Mail();
		}
	}
	


