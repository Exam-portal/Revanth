package com.revanth.onlineexam.dao;

import org.springframework.stereotype.Repository;

import com.revanth.onlineexam.model.User;

@Repository
public interface UserDao {

	public String login(User user);
	public void add(User user);
	public void changePassword(User user);
	public String viewPassword(User user);
}
