package com.revanth.onlineexam.controller;

public class loginException extends RuntimeException {
	
	public loginException() {
		super("cannot login");
	}
	public String toString() {
		return "cannot login kindly remove one letter"; 
	}

}
