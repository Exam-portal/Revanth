package com.revanth.onlineexam.controller;

public class ViewPasswordException extends RuntimeException {
	public ViewPasswordException() {
		super("password cannot be viewed successfully");
	}
	public String toString() {
		return "password cannot be viewed kindly remove one password";
	}

}
