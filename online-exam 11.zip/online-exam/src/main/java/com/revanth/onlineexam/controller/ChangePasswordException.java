package com.revanth.onlineexam.controller;

public class ChangePasswordException extends RuntimeException {

	public ChangePasswordException() {
		super("Password cannot be changed successfully");
		
	}
	public String toString() {
		return "Password cannot be changed kindly remove one password";
	}
}
