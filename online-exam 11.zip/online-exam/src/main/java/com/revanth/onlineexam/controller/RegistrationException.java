package com.revanth.onlineexam.controller;

public class RegistrationException extends RuntimeException {
	public RegistrationException() {
		super("cannot Register");
	}
	public String toString() {
		return "cannot Register kindly remove one letter"; 
	}

}
